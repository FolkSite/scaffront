afConfig = {
	assetsUrl: "/assets/components/ajaxform/"
	,actionUrl: "/assets/components/ajaxform/action.php"
	,closeMessage: "закрыть все"
	,formSelector: "form.ajax_form"
};
					