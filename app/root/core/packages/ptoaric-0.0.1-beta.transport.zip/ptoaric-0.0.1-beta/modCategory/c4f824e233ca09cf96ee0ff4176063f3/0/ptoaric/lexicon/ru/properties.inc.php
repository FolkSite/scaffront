<?php
$_lang['ptoaric.input']		= 'Изображение-источник.';
$_lang['ptoaric.options']	= 'Строка конфига для phpThumb. Например "w=150&h=200&q=100".';
$_lang['ptoaric.configs']	= 'Настройки ptoaric, которые перепишут глобальные. JSON.';