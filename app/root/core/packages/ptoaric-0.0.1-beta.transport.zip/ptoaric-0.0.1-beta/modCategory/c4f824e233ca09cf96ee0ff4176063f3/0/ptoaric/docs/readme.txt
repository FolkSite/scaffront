--------------------
ptoaric
--------------------
Author: Kartashov Alexey <ya.antixrist@gmail.com>
--------------------

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/antixrist/ptoaric/issues